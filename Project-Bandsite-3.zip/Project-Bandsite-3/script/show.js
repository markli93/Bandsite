//GET the show information from API and using DOM to display show table on the HTML

let p = axios.get('https://project-1-api.herokuapp.com/showdates?api_key=Mark Li')

function dispalyShow() {

p.then((response)=>{
    let showdatas= response.data;
    let table__Container = document.getElementById('table--container');
    let table__header = document.createElement('thead');
    let table__header__Row = document.createElement('tr');
    
    let header__Date = document.createElement('td');
    header__Date.innerText = 'Date';
    
    let header__Venue = document.createElement('td');
    header__Venue.innerText = 'Venue';
    
    let headerLocation = document.createElement('td');
    headerLocation.innerText = 'Location';
    
    table__header__Row.appendChild(header__Date);
    table__header__Row.appendChild(header__Venue);
    table__header__Row.appendChild(headerLocation);
    table__header.appendChild(table__header__Row);
    table__Container.appendChild(table__header);

    for(i=0;i<showdatas.length;i++){
        let show__Body = document.createElement('tbody');

        let table__row__Date = document.createElement('tr');

        let body__date__Header = document.createElement('th');
        body__date__Header.classList.add('table__tittle--hidden');
        body__date__Header.innerText = 'Date';

        let body__Date = document.createElement('td');
        body__Date.classList.add("table__date");
        body__Date.innerText = showdatas[i].date;

        table__row__Date.appendChild(body__date__Header);
        table__row__Date.appendChild(body__Date);
        
        let table__row__Venue = document.createElement('tr');

        let body__venue__Header =  document.createElement('th');
        body__venue__Header.classList.add('table__tittle--hidden');
        body__venue__Header.innerText = 'Venue';

        let  body__Venue =  document.createElement('td');
         body__Venue.classList.add("table__venue");
         body__Venue.innerText = showdatas[i].place;

        table__row__Venue.appendChild(body__venue__Header);
        table__row__Venue.appendChild( body__Venue);

        let table__row__Location = document.createElement('tr');

        let body__location__Header = document.createElement('th');
        body__location__Header.classList.add('table__tittle--hidden');
        body__location__Header.innerText='Location';

        let body__Location =  document.createElement('td');
        body__Location.classList.add("table__location");
        body__Location.innerText = showdatas[i].location;
        
        table__row__Location.appendChild(body__location__Header);
        table__row__Location.appendChild(body__Location);

        let table__button__Container = document.createElement('td');
        let table__Button = document.createElement('button');
        table__Button.classList.add('table__button');
        table__Button.innerText ='BUY TICKETS';
        table__button__Container.appendChild(table__Button);

        show__Body.appendChild(table__row__Date);
        show__Body.appendChild(table__row__Venue);
        show__Body.appendChild(table__row__Location);
        show__Body.appendChild(table__button__Container);
        table__Container.appendChild(show__Body);
    } 
});

p.catch((error)=>{
    console.log(error);
});   
}
 dispalyShow();