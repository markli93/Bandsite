

// create a function that GET comments form API and use DOM to append comments on to HTML

let outputComment = document.getElementById('outputComment')

function displayComment(){
    let p = axios.get('https://project-1-api.herokuapp.com/comments?api_key=MarkLi/')
    p.then((response)=>{
        let newArray = response.data;  
        console.log(response.data);
        for(i = newArray.length-1;i >=0; i--){

            var Container = document.createElement('div');
            Container.classList.add('comment__Container');
       
            var logo= document.createElement('div');
            logo.classList.add('comment__logo');
       
            var header__container = document.createElement('div');
            header__container.classList.add('comment__username--container');
       
            var usernme__container =document.createElement('div');
            usernme__container.classList.add('comment__username--spacing');
       
            var Name = document.createElement('div');
            Name.innerText = newArray[i].name;
            Name.classList.add('comment__username');
       
            var date = document.createElement('div');
            date.innerText = getdates(newArray[i].timestamp);
          
            var comment = document.createElement('div');
            comment.innerText= newArray[i].comment;
            comment.classList.add('comment__text');
      

            var moment = document.createElement('div');
            moment.innerText = momentsAgo(newArray[i].timestamp);
            moment.classList.add('comment__moment');

            
            usernme__container.appendChild(Name);
            usernme__container.appendChild(date);
       
            header__container.appendChild(logo);
            header__container.appendChild(usernme__container);
       
            Container.appendChild(header__container);
            Container.appendChild(comment);
            Container.appendChild(moment);
       
            outputComment.appendChild(Container);
     }
    });

    p.catch((error)=>{
        console.log(error);
    });
}


// Function that dispaly time when the comment was submitted

function getdates(timestamps) {
    var dateinput = new Date(timestamps);
    var day = dateinput.getDate();
    var month = dateinput.getMonth()+1; 
    var year = dateinput.getFullYear();
    
    if(day<10) {
        day='0'+day;
    } 

    if(month<10) {
        month='0'+month;
    } 

dateinput = month+'/'+day+'/'+year;
return dateinput;

}

// create a function that generate the relative time 

function momentsAgo(timestamps) {
    var momentConvert = new Date(timestamps);
    var momentago = moment(momentConvert).fromNow();
    return momentago;
}

 //  function call to display default comment when page loads.
 displayComment();

 //crate a new object that stores submitted information and post it to the api and display the comment on html

 var form = document.getElementById('form');
 document.getElementById('userInput').placeholder='Enter your name';
 document.getElementById('inputComment').placeholder='Add a new comment';



 form.addEventListener('submit',function(event){
     event.preventDefault();
     if(event.target.userInput.value === ''|| event.target.inputComment.value=== ''){
         alert('Input Invalid');
     }
     else{
        axios.post('https://project-1-api.herokuapp.com/comments?api_key=MarkLi/',
     {
        "name": event.target.userInput.value,
        "comment": event.target.inputComment.value
    })
    .then((success)=>{
        document.getElementById('outputComment').innerHTML = '';
        document.getElementById('userInput').value='';
        document.getElementById('inputComment').value='';
        displayComment();
    })
    .catch((error)=>{
        console.log(error);
    })
    
    }
 });