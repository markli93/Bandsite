

// create a function that GET comments form API and use DOM to append comments on to HTML

let outputComment = document.getElementById('outputComment')


function displayComment(){
    let p = axios.get('https://project-1-api.herokuapp.com/comments?api_key=Mark-Li')
    p.then((response)=>{
        let newArray = response.data;  

        for(i = newArray.length-1;i >=0; i--){

            let Container = document.createElement('div');
            Container.classList.add('comment__Container');
       
            let logo= document.createElement('div');
            logo.classList.add('comment__logo');
       
            let header__container = document.createElement('div');
            header__container.classList.add('comment__username--container');
       
            let usernme__container =document.createElement('div');
            usernme__container.classList.add('comment__username--spacing');
       
            let Name = document.createElement('div');
            Name.innerText = newArray[i].name;
            Name.classList.add('comment__username');
       
            let date = document.createElement('div');
            date.innerText = getdates(newArray[i].timestamp);
          
            let comment = document.createElement('div');
            comment.innerText= newArray[i].comment;
            comment.classList.add('comment__text');

            let moment = document.createElement('div');
            moment.innerText = momentsAgo(newArray[i].timestamp);
            moment.classList.add('comment__moment');

            usernme__container.appendChild(Name);
            usernme__container.appendChild(date);
       
            header__container.appendChild(logo);
            header__container.appendChild(usernme__container);
       
            Container.appendChild(header__container);
            Container.appendChild(comment);
            Container.appendChild(moment);
       
            outputComment.appendChild(Container);
        }

    });

    p.catch((error)=>{
        console.log(error);
    });
}

// Function that dispaly time when the comment was submitted

function getdates(timestamps) {
    let dateinput = new Date(timestamps);
    let day = dateinput.getDate();
    let month = dateinput.getMonth()+1; 
    let year = dateinput.getFullYear();
    
    if(day<10) {
        day='0'+day;
    } 

    if(month<10) {
        month='0'+month;
    } 

dateinput = month+'/'+day+'/'+year;
return dateinput;

}

// create a function that generate the relative time 

function momentsAgo(timestamps) {
    let momentConvert = new Date(timestamps);
    let momentago = moment(momentConvert).fromNow();
    return momentago;
}

 //  function call to display default comment when page loads.
 displayComment();
 
 
 //crate a new object that stores submitted information and post it to the api and display the comment on html
 let form = document.getElementById('form');
 document.getElementById('userInput').placeholder='Enter your name';
 document.getElementById('inputComment').placeholder='Add a new comment';

 form.addEventListener('submit',function(event){
     event.preventDefault();
     if(event.target.userInput.value === ''|| event.target.inputComment.value=== ''){
         alert('Input Invalid');
     }
     else{
        axios.post('https://project-1-api.herokuapp.com/comments?api_key=Mark-Li',
     {
        "name": event.target.userInput.value,
        "comment": event.target.inputComment.value
    })
    .then((success)=>{
        document.getElementById('outputComment').innerHTML = '';
        document.getElementById('userInput').value='';
        document.getElementById('inputComment').value='';
        displayComment();
    })
    .catch((error)=>{
        console.log(error);
    })
    
    }
 });